import tkinter as tk  
from tkinter import Menu, filedialog, Toplevel, messagebox 
from PIL import Image , ImageTk 


from filtres import*
from historique import mise_a_jour_historique, annuler, retablir

image_affichee = None 
image_secondaire = None 
historique = []
indice_historique = -1 # car 0 est la première image 
canvas = None


def rafraichir(): #demandé dans le TD 
    global image_affichee, canvas

    if image_affichee:
        I = ImageTk.PhotoImage(image_affichee) #convertir PIL en Tkinter 
        canvas.config(width=image_affichee.width, height=image_affichee.height)
        canvas.create_image(0, 0, anchor=tk.NW, image= I) #coller l'image en haut à gacuche 
        canvas.image = I  # Nécessaire pour éviter que l'image soit supprimée par le garbage collector

    tk.Button(dialogue_effet, text="Appliquer", command=lambda: (dialogue_effet.destroy())).pack(side=tk.LEFT, padx=10)
    tk.Button(dialogue_effet, text="Annuler", command=lambda: (annuler(), dialogue_effet.destroy())).pack(side=tk.RIGHT, padx=10)


class UVSQolorApp:

    def __init__(self, root):

        self.root = root
        self.root.title("UVSQolor")

        menu = Menu(root)
        root.config(menu=menu)

        #Menu fichier

        fichier = Menu(menu, tearoff=0)
        fichier.add_command(label="Ouvrir une image", command=self.open_image)
        menu.add_cascade(label="Fichier", menu=fichier)

        #Menu effets

        effets = Menu(menu, tearoff=0)
        effets.add_command(label="Sépia",command=lambda: self.open_dialog_slider("Sépia"),state=tk.DISABLED)
        effets.add_command(label="Luminosité",command=lambda: self.open_dialog_slider("Luminosité", 0.1, 3.0, 1.0, luminosité),state=tk.DISABLED)
        effets.add_command(label="Contraste (gamma pivoté)",command=lambda: self.open_dialog_slider("Contraste (gamma pivoté)", 0.1, 3.0, 1.0, contraste_gamma_pivoté),state=tk.DISABLED)
        effets.add_command(label="Flou uniforme",command=lambda: self.open_dialog_slider("Flou uniforme", 1, 15, 3, appliquer_flou),state=tk.DISABLED)
        effets.add_command(label="Flou Gaussien",command=lambda: self.open_dialog_slider("Flou Gaussien", 0.1, 10.0, 1.0, appliquer_flou_gaussien),state=tk.DISABLED)
        effets.add_command(label="Netteté",command=lambda: self.open_dialog_slider("Netteté", 0.0, 3.0, 1.0, netteté),state=tk.DISABLED)
        effets.add_command(label="Fusion avec une image",command=fusion_images,state=tk.DISABLED)

        menu.add_cascade(label="Effets", menu=effets)

        #Menu Historique

        historique_menu = Menu(menu, tearoff=0)
        historique_menu.add_command(label="Annuler", command= annuler)
        historique_menu.add_command(label="Rétablir", command= retablir)
        menu.add_cascade(label="Historique", menu=historique_menu)

        self.effets_menu = effets

        global canvas

        canvas = tk.Canvas(root, bg="white")
        canvas.pack()

    def open_dialog_slider(self, titre, minv, maxv, defv, cmd):

        global dialogue_effet

        dialogue_effet = Toplevel(self.root)
        dialogue_effet.title(titre)

        slider = tk.Scale(dialogue_effet, from_=minv, to=maxv, resolution=0.1,
                      orient=tk.HORIZONTAL, length=250, command=cmd)
    
        slider.set(defv) #valeur initiale du slider par defaut 

        slider.pack(pady=20)

        
        tk.Button(dialogue_effet, text="Appliquer", command=lambda: (dialogue_effet.destroy())).pack(side=tk.LEFT, padx=10)
        tk.Button(dialogue_effet, text="Annuler", command=lambda: (annuler(), dialogue_effet.destroy())).pack(side=tk.RIGHT, padx=10)


    def open_image(self):

        global image_affichee, historique, indice_historique

        path = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp")])

        if path:
            
            image = Image.open(path).convert("RGB")
            image_affichee = image.copy()
            historique = [image.copy()]
            indice_historique = 0
            self.enable_effects()
            rafraichir()

    def enable_effects(self): #tK.DISEABLED pour pas que les filtres se lance sns image et ca sert a lancer les ifltres 

        for i in range(self.effets_menu.index("end") + 1): # boucle parce que flm de tous réecrire
            self.effets_menu.entryconfig(i, state=tk.NORMAL)

