
def mise_a_jour_historique(nouvelle_image): 

    global historique, indice_historique, image_affichee

    historique = historique[:indice_historique + 1] #supprimer les images des indices supprimés (t à 5, si tu revients au 2, il faut uspprimer 3 et 4)
    historique.append(nouvelle_image.copy())
    indice_historique += 1
    image_affichee = nouvelle_image.copy() #mettre à jour l'image actuelle 
    
    return historique, indice_historique, image_affichee

def annuler(): #Undo, utile dans l'historique 

    global indice_historique, image_affichee

    if indice_historique > 0: #pour etre sur de pouvoi rrevenir en arrière 
        indice_historique -= 1 #reculer d'un eposition dans l'historique 
        image_affichee = historique[indice_historique].copy() #recuperer l'image précédente dans l'historique 

        return indice_historique, image_affichee

def retablir(): 

    global indice_historique, image_affichee

    if indice_historique < len(historique) - 1: #verifier qu'il existe uen étape après, pour pouvori avancer 
        indice_historique += 1
        image_affichee = historique[indice_historique].copy() #eviter de modifier directement l'image stockée

        return indice_historique, image_affichee