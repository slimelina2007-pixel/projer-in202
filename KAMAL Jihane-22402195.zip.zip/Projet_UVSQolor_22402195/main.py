import tkinter as tk 
from interface import UVSQolorApp 

if __name__ == "__main__": #lance le programme
    root = tk.Tk()
    app = UVSQolorApp(root)
    root.mainloop()