# Import des bibliothèques nécessaires
from tkinter import filedialog
from PIL import Image #pillow: manipulation image ( ouvrir modifier ET convertir et afficher)
import numpy as np #sert a travailler avec des tableaux et des matrices (image = matrice de pixel)
from scipy.signal import convolve2d  #logiciel pour calcul scientifique 
                                    #fonction qui applique un kernel sur une image 


def sepia (image_affichee):

    image = np.array(image, dtype = np.float32)

    sepia_filtre = np.array([
        [0.393, 0.769, 0.189],
        [0.349, 0.686, 0.168],
        [0.272, 0.534, 0.131],
    ])

    image_affichee = image.dot(sepia_filtre.T)
    image_affichee = np.clip(image_affichee, 0, 255).astypee(np.uint8)

    return Image.fromarray(image_affichee)


def luminosité (image_affichee, valeur):

    m = float(valeur)

    if image_affichee:
       
        gamma = np.log(m) / np.log(0.5) #calcul de gamma à partir de m 

        image = np.array(image_affichee, dtype=np.float32)  #conversion en tableau numpy 
        image = image ** gamma #correction gamma 
        image = np.clip(image, 0, 255).astype(np.uint8) #retour à l'echelle d'origine

        return Image.fromarray(image)

#REMARQUE: penser à rajouter la normalisation avec max_value 

def contraste_gamma_pivoté(image_affichee, c, p):

    gamma = 2** c

    if image_affichee:
        
        image = np.array(image_affichee, dtype=np.float32) / 255.0 #convertir l'image ne tableau float 
        image = image / 255.0

        mask_bas = image <= p
        mask_haut = image > p 

        # Partie 1: x <= p
        image [mask_bas] = p * ((image[mask_bas] / p) ** gamma)

        #Partie 2: x > p
        image [mask_haut] = 1 - (1 - p) * (((1 - image [mask_haut]) /(1-p)) ** gamma)
         
        image = (image * 255).clip(0, 255).astype(np.uint8) #remise à l'echelle 0 - 255

        return Image.fromarray(image)


def appliquer_flou(image_affichee, valeur):
    
    if image_affichee:
        
        kernel_size = int(valeur) #taille du flou 
        if kernel_size <= 0: # on fait r 
            return
        
        kernel = np.ones((kernel_size, kernel_size ), dtype=np.float32) / (kernel_size * kernel_size) #c'est un noyau de convolution uniforme (M = 1/nbr element)

        img_array = np.array(image_affichee) #tableau NumPy de l'image
        result = np.zeros_like(img_array) #tableau vide pour stocker l'image flouter 

        for i in range(3): #la consigne veut qu'on appique le flou sur R, G, B séparemment 
            result[:, :, i] = convolve2d(img_array[:, :, i], kernel, mode='same', boundary='symm') #convolve2d applique le flou, mode same garde ala meme taille, boundary ="symm" gère les bords en les relfetant

        return Image.fromarray(result)


def appliquer_flou_gaussien(image_affichee, valeur):

    if image_affichee:
       
        sigma = float(valeur) #controle l'intensité du flou 
        if sigma <= 0:
            return
        
        size = int(2 * np.ceil(3 * sigma) + 1) #calcul de la taille du noyau 
        
        #création de la courbe gaussienne == Mathematiques 1D
        x = np.linspace(-3*sigma, 3*sigma, size) 
        gauss = np.exp(-x**2 / (2*sigma**2)) 
        gauss /= gauss.sum()

        #création du noyau gaussien 2D
        kernel = np.outer(gauss, gauss)

        #convetion de l'image en tableau
        img_array = np.array(image_affichee)
        result = np.zeros_like(img_array)

        for i in range(3): # comme pour le contraste (R, G, B)
            result[:, :, i] = convolve2d(img_array[:, :, i], kernel, mode='same', boundary='symm')

        return Image.fromarray(result)


def netteté(image_affichee, valeur):

    if image_affichee:

        alpha = float(valeur) #valeur récuperer dans le slider 
        img_array = np.array(image_affichee, dtype = np.float32)

        #flou (noyau 3x3)
        kernel = np.ones((3, 3), dtype=np.float32) / 9
        B = np.zeros_like(img_array)

        for i in range(3):
            B[:,:,i] = convolve2d(img_array[:,:,i], kernel, mode = "same", boundary="symm")
        
        D = img_array - B 

        #netteté 
        sharp = img_array + alpha * D

        sharp = np.clip(sharp, 0, 255).astype(np.uint8)

        return Image.fromarray(sharp)


def fusion_images(image_affichee):

    if image_affichee:

        path = filedialog.askopenfilename(title="Charger la deuxième image") #une autre fenetre s'ouvre pour choisir une image secondaire 

        if path:
            #charge l'image depuis le dique, convertit en 3 cannaux(pour que les deux images ont le meme format) et redimenssione (pour qu'elles aient la meme taille )
            img2 = Image.open(path).convert("RGB").resize(image_affichee.size)
            fusion = Image.blend(image_affichee, img2, alpha=0.5)

            return fusion
