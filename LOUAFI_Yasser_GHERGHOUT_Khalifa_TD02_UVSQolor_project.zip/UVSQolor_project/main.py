# Import des bibliothèques nécessaires
import tkinter as tk
from tkinter import Menu, filedialog, Toplevel, messagebox
from PIL import Image, ImageTk
import numpy as np
from scipy.signal import convolve2d

# Déclaration des variables globales
image_affichee = None              # Image actuellement affichée
canvas = None                      # Zone de dessin pour l'image
fenetre_principale = None         # Fenêtre principale de l'application
image_secondaire = None           # Deuxième image utilisée pour la fusion
historique = []                   # Historique des modifications
indice_historique = -1            # Position actuelle dans l'historique
dialogue_effet = None             # Fenêtre de dialogue pour les effets

# Rafraîchissement de l'affichage sur le canvas

def rafraichir():
    global image_affichee, canvas
    if image_affichee:
        temp = ImageTk.PhotoImage(image_affichee)
        canvas.config(width=image_affichee.width, height=image_affichee.height)
        canvas.create_image(0, 0, anchor=tk.NW, image=temp)
        canvas.image = temp  # Nécessaire pour éviter que l'image soit supprimée par le garbage collector

# Mise à jour de l'historique avec une nouvelle image

def mise_a_jour_historique(nouvelle_image):
    global historique, indice_historique, image_affichee
    historique = historique[:indice_historique + 1]
    historique.append(nouvelle_image.copy())
    indice_historique += 1
    image_affichee = nouvelle_image.copy()
    rafraichir()

# Annuler la dernière action

def annuler():
    global indice_historique, image_affichee
    if indice_historique > 0:
        indice_historique -= 1
        image_affichee = historique[indice_historique].copy()
        rafraichir()

# Rétablir l'action annulée

def retablir():
    global indice_historique, image_affichee
    if indice_historique < len(historique) - 1:
        indice_historique += 1
        image_affichee = historique[indice_historique].copy()
        rafraichir()

# Appliquer un filtre de couleur personnalisé (rouge, vert, bleu, violet)

def filtre_couleur(r_on, g_on, b_on):
    global image_affichee
    if image_affichee:
        img = image_affichee.copy()
        pixels = img.load()
        for i in range(img.width):
            for j in range(img.height):
                r, g, b = pixels[i, j]
                pixels[i, j] = (
                    r if r_on else 0,
                    g if g_on else 0,
                    b if b_on else 0
                )
        image_affichee = img
        rafraichir()

# Fonctions dédiées à chaque filtre couleur

def filtre_rouge(): filtre_couleur(True, False, False)
def filtre_vert(): filtre_couleur(False, True, False)
def filtre_bleu(): filtre_couleur(False, False, True)
def filtre_violet(): filtre_couleur(True, False, True)

# Filtre de niveaux de gris

def filtre_gris():
    global image_affichee
    if image_affichee:
        img = image_affichee.copy()
        pixels = img.load()
        for i in range(img.width):
            for j in range(img.height):
                r, g, b = pixels[i, j]
                grey = int((r + g + b) / 3)
                pixels[i, j] = (grey, grey, grey)
        image_affichee = img
        rafraichir()

# Correction gamma

def correction_gamma(valeur):
    global image_affichee
    gamma = float(valeur)
    if image_affichee:
        base = image_affichee
        arr = np.array(base, dtype=np.float32) / 255.0
        arr = np.power(arr, gamma) * 255
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        image_affichee = Image.fromarray(arr)
        rafraichir()

# Correction par fonction sigmoïde

def correction_sigmoide(contraste, pente):
    global image_affichee
    if image_affichee:
        base = image_affichee
        arr = np.array(base, dtype=np.float32) / 255.0
        arr = 1 / (1 + np.exp(-pente * (contraste * (arr - 0.5))))
        arr = (arr * 255).clip(0, 255).astype(np.uint8)
        image_affichee = Image.fromarray(arr)
        rafraichir()

# Flou moyen avec noyau carré

def appliquer_flou(valeur):
    global image_affichee
    if image_affichee:
        base = image_affichee
        kernel_size = int(valeur)
        if kernel_size <= 0:
            return
        kernel = np.ones((kernel_size, kernel_size), dtype=np.float32) / (kernel_size * kernel_size)
        img_array = np.array(base)
        result = np.zeros_like(img_array)
        for i in range(3):
            result[:, :, i] = convolve2d(img_array[:, :, i], kernel, mode='same', boundary='symm')
        image_affichee = Image.fromarray(np.clip(result, 0, 255).astype(np.uint8))
        rafraichir()

# Flou gaussien avec noyau généré

def appliquer_flou_gaussien(valeur):
    global image_affichee
    if image_affichee:
        base = image_affichee
        sigma = float(valeur)
        if sigma <= 0:
            return
        size = int(2 * np.ceil(3 * sigma) + 1)
        x = np.linspace(-3*sigma, 3*sigma, size)
        gauss = np.exp(-x**2 / (2*sigma**2))
        gauss /= gauss.sum()
        kernel = np.outer(gauss, gauss)
        img_array = np.array(base)
        result = np.zeros_like(img_array)
        for i in range(3):
            result[:, :, i] = convolve2d(img_array[:, :, i], kernel, mode='same', boundary='symm')
        image_affichee = Image.fromarray(np.clip(result, 0, 255).astype(np.uint8))
        rafraichir()

# Détection des bords avec filtre Sobel

def detecter_bords():
    global image_affichee
    if image_affichee:
        base = image_affichee
        img_array = np.array(base.convert('L'))
        sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
        sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
        gx = convolve2d(img_array, sobel_x, mode='same', boundary='symm')
        gy = convolve2d(img_array, sobel_y, mode='same', boundary='symm')
        magnitude = np.sqrt(gx**2 + gy**2)
        magnitude = np.clip(magnitude, 0, 255).astype(np.uint8)
        image_affichee = Image.fromarray(magnitude)
        rafraichir()

# Fusion de deux images

def fusion_images():
    global image_affichee, image_secondaire
    if image_affichee:
        path = filedialog.askopenfilename(title="Charger la deuxième image")
        if path:
            img2 = Image.open(path).convert("RGB").resize(image_affichee.size)
            fusion = Image.blend(image_affichee, img2, alpha=0.5)
            image_affichee = fusion
            rafraichir()

# Boîte de dialogue pour les effets avec slider

def open_dialog_slider(titre, minv, maxv, defv, cmd, apply_func):
    global dialogue_effet
    dialogue_effet = Toplevel(fenetre_principale)
    dialogue_effet.title(titre)
    slider = tk.Scale(dialogue_effet, from_=minv, to=maxv, resolution=0.1,
                      orient=tk.HORIZONTAL, length=250, command=cmd)
    slider.set(defv)
    slider.pack(pady=20)
    tk.Button(dialogue_effet, text="Appliquer", command=lambda: (apply_func(), dialogue_effet.destroy())).pack(side=tk.LEFT, padx=10)
    tk.Button(dialogue_effet, text="Annuler", command=lambda: (annuler(), dialogue_effet.destroy())).pack(side=tk.RIGHT, padx=10)

# Boîte de dialogue spécifique à la correction sigmoïde

def open_dialog_sigmoide():
    global dialogue_effet
    dialogue_effet = Toplevel(fenetre_principale)
    dialogue_effet.title("Contraste (sigmoïde)")

    tk.Label(dialogue_effet, text="Contraste").pack()
    slider1 = tk.Scale(dialogue_effet, from_=-3, to=3, resolution=0.1,
                       orient=tk.HORIZONTAL, length=250)
    slider1.set(1.0)
    slider1.pack()

    tk.Label(dialogue_effet, text="Pente").pack()
    slider2 = tk.Scale(dialogue_effet, from_=1, to=30, resolution=1,
                       orient=tk.HORIZONTAL, length=250)
    slider2.set(10)
    slider2.pack()

    def update(_=None):
        correction_sigmoide(slider1.get(), slider2.get())

    slider1.config(command=lambda x: update())
    slider2.config(command=lambda x: update())

    tk.Button(dialogue_effet, text="Appliquer", command=lambda: (appliquer_effet_temporaire(), dialogue_effet.destroy())).pack(side=tk.LEFT, padx=10)
    tk.Button(dialogue_effet, text="Annuler", command=lambda: (annuler(), dialogue_effet.destroy())).pack(side=tk.RIGHT, padx=10)

# Appliquer l'effet actuellement affiché (et l'ajouter à l'historique)

def appliquer_effet_temporaire():
    global image_affichee
    if image_affichee:
        mise_a_jour_historique(image_affichee)

# Sauvegarde de l'image modifiée

def sauvegarder_image():
    global image_affichee
    if image_affichee:
        filepath = filedialog.asksaveasfilename(defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("BMP", "*.bmp")])
        if filepath:
            try:
                image_affichee.save(filepath)
                messagebox.showinfo("Succès", "Image sauvegardée avec succès.")
            except Exception as e:
                messagebox.showerror("Erreur", str(e))

# Classe principale de l'application UVSQolor

class UVSQolorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("UVSQolor")

        menu = Menu(root)
        root.config(menu=menu)

        fichier = Menu(menu, tearoff=0)
        fichier.add_command(label="Ouvrir une image", command=self.open_image)
        fichier.add_command(label="Sauvegarder l'image", command=sauvegarder_image)
        menu.add_cascade(label="Fichier", menu=fichier)

        effets = Menu(menu, tearoff=0)
        effets.add_command(label="Filtre vert", command=filtre_vert, state=tk.DISABLED)
        effets.add_command(label="Filtre gris", command=filtre_gris, state=tk.DISABLED)
        effets.add_command(label="Filtre rouge", command=filtre_rouge, state=tk.DISABLED)
        effets.add_command(label="Filtre bleu", command=filtre_bleu, state=tk.DISABLED)
        effets.add_command(label="Filtre violet", command=filtre_violet, state=tk.DISABLED)
        effets.add_command(label="Luminosité (gamma)", command=lambda: open_dialog_slider("Gamma", 0.1, 3.0, 1.0, correction_gamma, appliquer_effet_temporaire), state=tk.DISABLED)
        effets.add_command(label="Contraste (sigmoïde)", command=open_dialog_sigmoide, state=tk.DISABLED)
        effets.add_command(label="Flou uniforme", command=lambda: open_dialog_slider("Flou uniforme", 0, 10, 1, appliquer_flou, appliquer_effet_temporaire), state=tk.DISABLED)
        effets.add_command(label="Flou Gaussien", command=lambda: open_dialog_slider("Flou Gaussien", 0.0, 10.0, 1.0, appliquer_flou_gaussien, appliquer_effet_temporaire), state=tk.DISABLED)
        effets.add_command(label="Détection de bords", command=detecter_bords, state=tk.DISABLED)
        effets.add_command(label="Fusion avec une image", command=fusion_images, state=tk.DISABLED)
        menu.add_cascade(label="Effets", menu=effets)

        historique_menu = Menu(menu, tearoff=0)
        historique_menu.add_command(label="Annuler", command=annuler)
        historique_menu.add_command(label="Rétablir", command=retablir)
        menu.add_cascade(label="Historique", menu=historique_menu)

        self.effets_menu = effets

        global canvas
        canvas = tk.Canvas(root, bg="white")
        canvas.pack()

    def open_image(self):
        global image_affichee, historique, indice_historique
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp")])
        if path:
            image = Image.open(path).convert("RGB")
            image_affichee = image.copy()
            historique = [image.copy()]
            indice_historique = 0
            self.enable_effects()
            rafraichir()

    def enable_effects(self):
        for i in range(self.effets_menu.index("end") + 1):
            self.effets_menu.entryconfig(i, state=tk.NORMAL)

# Lancement de l'application
if __name__ == "__main__":
    fenetre_principale = tk.Tk()
    app = UVSQolorApp(fenetre_principale)
    fenetre_principale.mainloop()
